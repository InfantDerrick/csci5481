# How to Run!

```bash
javac NeedlemanWunsch.java
java NeedlemanWunsch [seq1Path] [seq2Path] [out] [fixedGapPenalty] [mismatchPenalty] [match] [startEndPenalty]
```
