@author: Infant Derrick Gnana Susairaj

```bash
javac Homework3Driver.java
java Homework3Driver hw3.fna
```
